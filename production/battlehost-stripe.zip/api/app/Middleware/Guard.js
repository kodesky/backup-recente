'use strict'

class Guard {
 
  async handle ({ request, response }, next) {
    const clientId = request.header('Client-ID')

    if (!clientId) {
      return response.status(401).json({
        message: 'Client ID not sent'
      })
    }

    request.clientId = clientId

    await next()
  }
}

module.exports = Guard
