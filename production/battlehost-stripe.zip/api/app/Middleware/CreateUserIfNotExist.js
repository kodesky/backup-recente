'use strict'

const User = use('App/Models/User')
const Env = use('Env')

const stripe = require('stripe')(Env.get('STRIPE_SECRET'));

class CreateUserIfNotExist {
  async handle ({ request }, next) {
    const data = await User.query().where({ customer_id: request.clientId }).fetch()

    if (JSON.parse(JSON.stringify(data)).length === 0) {
      const customer = await stripe.customers.create();

      await User.create({
        customer_id: request.clientId,
        secret: customer.id
      })
    }

    const user = await User.find(request.clientId)

    request.secret = user.secret

    await next()
  }
}

module.exports = CreateUserIfNotExist
