'use strict'

const Env = use('Env')

class IpGuard {
  async handle ({ request, response }, next) {
    const ip = request.ip()
    const allowed = Env.get('ALLOW_IPS').split(',')

    if (!allowed.includes(ip)) {
      response.status(401).send(`${ip} is not allowed`)
    }

    await next()
  }
}

module.exports = IpGuard
