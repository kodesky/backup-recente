'use strict'

const Env = use('Env')
const stripe = require('stripe')(Env.get('STRIPE_SECRET'));

const Transaction = use('App/Models/Transaction')

class CustomerController {
  async getCards ({ request }) {
    const paymentMethods = await stripe.paymentMethods.list({
      customer: request.secret,
      type: 'card',
    });

    return paymentMethods
  }

  async removeCard ({ params: { id } }) {
    await stripe.paymentMethods.detach(id)
  }

  async transactions ({ request }) {
    const transactions = await Transaction.query().where({ user_id: request.clientId }).fetch()
  
    return transactions
  }
}

module.exports = CustomerController
