'use strict'

const axios = require('axios').default

const Env = use('Env')
const User = use('App/Models/User')
const Transaction = use('App/Models/Transaction')

const stripe = require('stripe')(Env.get('STRIPE_SECRET'))

class PaymentController {
  async getIntent ({ request, response }) {
    const { amount, currency } = request.all()

    const intent = await stripe.paymentIntents.create({
      amount,
      currency,
      customer: request.secret
    })

    return response.status(200).json(intent)
  }

  async manual ({ request, response }) {
    const { amount, currency, payment_method } = request.all()

    const paymentMethods = await stripe.paymentMethods.list({
      customer: request.secret,
      type: 'card',
    });

    try {
      const intent = await stripe.paymentIntents.create({
        payment_method: payment_method !== null ? payment_method : paymentMethods.data[0].id,
        customer: request.secret,
        amount,
        currency,
        confirmation_method: 'manual',
        confirm: true
      });

      if (intent.status === 'succeeded') {
        return response.status(200).json({ message: 'Recarga efetuada com sucesso!' })
      } else {
        return response.status(401).json({ message: 'Recarga não autorizada' })
      }
    } catch (err) {
      response.status(400).json({ message: 'Não foi possível completar a transação' })
    }
  }

  async payWithSavedCard ({ request, params: { payment_method }, response }) {
    const { amount, currency } = request.all()

    try {
      const intent = await stripe.paymentIntents.create({
        amount,
        currency,
        customer: request.secret,
        payment_method,
        off_session: true,
        confirm: true,
      })

      if (intent.status === 'succeeded') {
        return response.status(200).json({ message: 'Recarga efetuada com sucesso!' })
      } else {
        return response.status(401).json({ message: 'Recarga não autorizada' })
      }
    } catch (err) {
      response.status(400).json({ message: 'Não foi possível completar a transação' })
    }
  }

  async notification ({ request }) {
    const event = request.all()


    if (event.type === 'payment_intent.succeeded') {
      const data = event.data.object 
      const { amount, currency, customer: secret, charges: { data: chargesData } } = data

      const { payment_method_details: { card: { brand, country, exp_month, exp_year, last4 } }} = chargesData[0]

      var user = await User.query().where({ secret }).orderBy('id', 'DESC').fetch()
      user = JSON.parse(JSON.stringify(user))[0]

      const transaction = await Transaction.create({
        user_id: user.id,
        amount: amount / 100,
        currency,
        brand, 
        country, 
        exp_month, 
        exp_year, 
        last4
      })

      await axios.post(Env.get('NOTIFICATION_URL'), {
        transaction,
        gateway_response: data
      })
    }
  }
}

module.exports = PaymentController
