'use strict'

/** @type {typeof import('@adonisjs/framework/src/Route/Manager')} */
const Route = use('Route')


// CUSTOMER ROUTES
Route.group(() => {
  Route.get('transactions', 'CustomerController.transactions')

  Route.get('cards', 'CustomerController.getCards')
  Route.delete('card/:id', 'CustomerController.removeCard')
}).prefix('customer').middleware(['ipguard', 'guard', 'cuine'])

// PAYMENT ROUTES
Route.group(() => {
  Route.post('authorization/:payment_method', 'PaymentController.payWithSavedCard')
  Route.post('authorization', 'PaymentController.getIntent')
  Route.post('charge', 'PaymentController.manual')
}).prefix('payment').middleware(['ipguard', 'guard', 'cuine'])

  
Route.post('notification', 'PaymentController.notification')

