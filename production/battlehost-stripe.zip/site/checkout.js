var stripe = Stripe('pk_test_zub4nRapa3gtGIqPIW3rISS000CuUpikpg');

/**
 * MANUAL PAY
 */
var style = {
  base: {
    color: "#686de0",
  }
};
var elements = stripe.elements();

const rechargeAmount = document.querySelector('#recharge-amount')

var card = elements.create("card", { style: style });
card.mount("#card-element");

card.on('change', function(event) {
  var displayError = document.getElementById('card-errors');
  if (event.error) {
    displayError.textContent = event.error.message;
  } else {
    displayError.textContent = '';
  }
});

var form = document.getElementById('payment-form');

form.addEventListener('submit', function(ev) {
  ev.preventDefault();

  const formButton = document.getElementById('submit')

  formButton.attributes.disabled = true;
  formButton.innerHTML = "Aguarde..."

  fetch('http://localhost:3333/payment/authorization', {
    method: 'POST',
    body: JSON.stringify({
      amount: parseFloat(rechargeAmount.value) * 100,
      currency: 'brl',
    }),
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'Client-ID': '1'
    }
  }).then(function(response) {
    return response.json();
  }).then(function(responseJson) {
    var clientSecret = responseJson.client_secret;

    var data = {
      payment_method: {
        card: card,
        billing_details: {
          name: document.querySelector('#card-holder').value
        },
      },
    }

    if (document.querySelector('#save-card').checked) {
      data = {
        ...data,
        setup_future_usage: 'off_session'
      }
    }
    
    stripe.confirmCardPayment(clientSecret, data).then(function(result) {
      if (result.error) {
        var alertDiv = document.querySelector('#alert')

        alertDiv.style.display = 'block'
        alertDiv.innerHTML = result.error.message
      } else {
        if (result.paymentIntent.status === 'succeeded') {
          alert('Pagamento concluido')
        }
      }

      formButton.attributes.disabled = false;
      formButton.innerHTML = "Pagar"
    });
  });
});

/** PAY WITH SAVED CARD */
function payWithSavedCard(paymentMethod) {
  fetch(`http://localhost:3333/payment/authorization/${paymentMethod}`, {
    method: 'POST',
    body: JSON.stringify({
      amount: parseFloat(rechargeAmount.value) * 100,
      currency: 'brl',
    }),
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'Client-ID': '1'
    }
  }).then(function(response) {
    return response.json();
  }).then(function(responseJson) {
    const { message } = responseJson

    alert(message)
  });
}


/** REMOVE CARD */
function removeCard(paymentMethod) {
  fetch(`http://localhost:3333/customer/card/${paymentMethod}`, {
    method: 'DELETE',
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'Client-ID': '1'
    }
  }).then(function(responseJson) {
    alert('Cartão removido')

    window.location.reload()
  });
}