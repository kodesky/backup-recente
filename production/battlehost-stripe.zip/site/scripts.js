fetch('http://localhost:3333/customer/cards', {
  method: 'GET',
  headers: {
    Accept: 'application/json',
    'Content-Type': 'application/json',
    'Client-ID': '1',
  },
})
  .then(function (response) {
    return response.json();
  })
  .then(function (responseJson) {
    const { data } = responseJson;

    const cards = document.querySelector('#saved-cards');

    data.forEach(function (card) {
      const element = document.createElement('div');

      element.classList.add('col-md-6');
      element.innerHTML =
        `<button class="btn-card" onclick="payWithSavedCard('${card.id}')">` +
        '<div class="btn-card-header">' +
        `<img src="http://logo.clearbit.com/${card.card.brand}.com" alt="Credit Card" />` +
        `<div class="btn-card-last">${card.card.last4}</div>` +
        '</div>' +
        '<div>' +
        `<p><b>Vencimento</b> ${card.card.exp_month}/${card.card.exp_year}</p>` +
        '</div>' +
        `<button class="btn-card-remove" onclick="removeCard('${card.id}')"><i class="fas fa-trash"></i></button>` +
        '</button>';

      cards.appendChild(element);
    });
  });
